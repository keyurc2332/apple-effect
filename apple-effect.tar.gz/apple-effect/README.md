# 🍎 Apple Effect
### *An ML-powered Product Perception Intelligence System*

> Apple told us what it thought mattered.  
> This project asks what consumers actually thought mattered.

---

## What this is

Apple Effect analyses public consumer-generated text around the **iPhone Duo** (Apple's first foldable, launched September 9, 2026) and the **iPhone 18 Pro / Pro Max** to answer:

> **What product features are driving positive and negative consumer perception — and which are associated with expressed purchase intent?**

This is not a hype tracker. It is an **Aspect-Based Sentiment Analysis (ABSA)** system that decomposes individual comments into structured feature-level opinions.

---

## Core question

Instead of:
```
Comment → Mixed sentiment
```

This system produces:
```
Comment → Foldable design: Positive
          Price:           Negative
          Purchase intent: Conditional
```

---

## Build phases

| Phase | Description | Status |
|-------|-------------|--------|
| 0 | Data source validation | ✅ Ready |
| 1 | Pilot data collection | ⬜ |
| 2 | EDA | ⬜ |
| 3 | NLP pipeline | ⬜ |
| 4 | Human labelling (ground truth) | ⬜ |
| 5 | Train / evaluate models | ⬜ |
| 6 | Purchase intent | ⬜ |
| 7 | Statistical analysis | ⬜ |
| 8 | Robustness / failure analysis | ⬜ |
| 9 | Dashboard | ⬜ |
| 10 | Deploy (Streamlit) | ⬜ |
| 11 | Documentation | ⬜ |

---

## Setup

```bash
git clone https://github.com/YOUR_USERNAME/apple-effect
cd apple-effect

python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt

cp .env.example .env
# Then add your API keys to .env
```

---

## Phase 0 — Validate data sources

```bash
python src/data_collection/validate_sources.py
```

This checks:
- YouTube Data API access
- Reddit API (optional — only if you have authorized access)
- Google Trends
- All NLP/ML libraries

---

## Phase 1 — Collect pilot data

```bash
python src/data_collection/youtube_collector.py
```

Collects ~50 videos and ~5,000–10,000 comments in pilot mode.  
Set `PILOT_MODE = False` for a full collection run.

---

## Data sources

| Source | Status | Notes |
|--------|--------|-------|
| YouTube Data API | Primary | Comments + video metadata |
| Reddit API | Optional | Requires authorized access per Reddit policy |
| Google Trends | Contextual | Interest-over-time for launch queries |

---

## NLP pipeline

```
Comment
  ↓ Clean (URLs, spam, near-duplicates, language filter)
  ↓ Aspect extraction (rule-based → transformer)
  ↓ Sentiment per aspect (lexicon → zero-shot NLI → fine-tuned)
  ↓ Purchase intent classification
  ↓ Embeddings (Sentence Transformers)
  ↓ Clustering (HDBSCAN / K-Means)
  → Feature × Sentiment matrix
```

---

## Aspect taxonomy

| Category | Aspects |
|----------|---------|
| Hardware | foldable_design, display, camera, battery, performance, durability |
| Software | ai_siri, multitasking |
| Commercial | price, upgrade |
| Ecosystem | ecosystem |
| Competitive | comparison_samsung |

---

## Tech stack

- **Data**: YouTube Data API v3, pytrends
- **NLP**: Hugging Face Transformers, Sentence Transformers, spaCy
- **ML**: scikit-learn, XGBoost
- **Clustering**: UMAP + HDBSCAN
- **Stats**: SciPy, statsmodels
- **Viz**: Plotly, Matplotlib
- **App**: Streamlit

---

## Project structure

```
apple-effect/
├── data/
│   ├── raw/           # never committed (in .gitignore)
│   ├── processed/
│   └── external/
├── notebooks/
│   ├── 01_data_exploration.ipynb
│   ├── 02_sentiment_analysis.ipynb
│   ├── 03_topic_modeling.ipynb
│   ├── 04_purchase_intent.ipynb
│   └── 05_statistical_analysis.ipynb
├── src/
│   ├── data_collection/
│   │   ├── validate_sources.py    ← start here (Phase 0)
│   │   ├── youtube_collector.py   ← Phase 1
│   │   └── trends_collector.py
│   ├── preprocessing/
│   │   └── cleaner.py
│   ├── nlp/
│   │   └── absa.py                ← aspect-based sentiment
│   ├── models/
│   ├── evaluation/
│   └── visualization/
├── app/
│   └── app.py                     ← Streamlit dashboard (Phase 9)
├── models/
├── outputs/
├── requirements.txt
├── .env.example
└── README.md
```

---

## Ethics & data use

- No Reddit data without authorized API access
- No scraping to bypass platform policies
- Unit of analysis is the **opinion text**, not the individual user
- No individual usernames stored or exposed in outputs
- Complies with YouTube Data API Terms of Service

---

## License

MIT
